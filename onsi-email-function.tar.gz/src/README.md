# ONSi Email Function

This is an Appwrite function that sends order confirmation emails to customers and admin notifications.

## Environment Variables Required

Set these in your Appwrite Function settings:

- `SMTP_HOST`: smtp.gmail.com
- `SMTP_USERNAME`: rayentroudi00@gmail.com
- `SMTP_PASSWORD`: laoelooltsiaonfm
- `SUBMIT_EMAIL`: rayentroudi00@gmail.com
- `ALLOWED_ORIGINS`: *

## Runtime

Node.js 22

## Entry Point

main.js
